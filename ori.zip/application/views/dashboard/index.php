<div class="col-lg-6">
    <div class="row">
        <div class="alert alert-success pt-3">
            <h5>Welcome akhmadikhza123@gmail.com</h2>
        </div>
    </div>
</div>