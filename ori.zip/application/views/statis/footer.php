
<div class="footer">

  <div class="row d-flex justify-content-around" style="margin-top: 20px;">
    <div class="container">
      <div class="col-lg-6">

        <p style="color: white;font-size: 20px;" class=""> Ikhza E-Voting &copy; 2021 </p>
        <p style="color: white" class=""><i class="fa fa-map-marker" style="color: red" aria-hidden="true"></i> Address: Jl.H.Ibrahim Desa Mernek Kec.Maos Kab.Cilacap</p>
        <p style="color: white" class=""><i class="fa fa-phone" aria-hidden="true"></i> Telepon: 083104835777</p>
        <p style="color: white;" class=""><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: akhmadikhza123@gmail.com</p>

        <a href="https://wa.link/k6palq"><i class="fa fa-whatsapp" style="font-size:35px;color:white" aria-hidden="true"></i></a>
        <a href="https://instagram.com/pripnuippnu_mernek?igshid=uzl39aqtszx4"><i class="fa fa-instagram" style="font-size:35px;color:white" aria-hidden="true"></i></a>
        <a href=""><i class="fa fa-facebook-square" style="font-size:35px;color:white" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-twitter-square" style="font-size:35px; color: white" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-youtube" style="font-size:35px; color: white" aria-hidden="true"></i></a>

      </div>
      <p style="color: white; font-size: 14px;" class="footer-p text-center">Copyright&copy;Ikhza E-Voting 2021. All Rights Reserved.</p>
    </div>

  </div>



</div><!-- Footer -->





  </body>
</html>
