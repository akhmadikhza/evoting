<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

     <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Viga" rel="stylesheet">


     <link href="<?= base_url(''); ?>assets2/assets/sbadmin/dist/css/styles.css" rel="stylesheet" />
    <script src="<?php echo base_url('assets2/assets/js/jquery-3.2.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets2/assets/js/materialize.min.js'); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.9.1/sweetalert2.min.js"></script>
    <script src="<?php echo base_url('assets2/assets/js/jquery-ui.min.js'); ?>"></script>

    <link rel="stylesheet" href="<?php echo base_url('assets2/assets/css/materialize.min.css'); ?>">

     <link rel="stylesheet" href="<?php echo base_url('assets2/assets/css/me.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.9.1/sweetalert2.min.css" />

     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <title><?= $title; ?></title>
  
  </head>
  <body>


   